class SessionManager {
  static Future<void> login() async {
    // Simulate session saving
    await Future.delayed(const Duration(milliseconds: 200));
  }
}